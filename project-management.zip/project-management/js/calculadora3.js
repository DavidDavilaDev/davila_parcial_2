document.getElementById('formulario3').addEventListener('submit', function(event) {
    event.preventDefault();
    const unidades_producidas = parseFloat(document.getElementById('unidades_producidas3').value);
    const tiempo_planeado = parseFloat(document.getElementById('tiempo_planeado3').value);
    const tiempo_real = parseFloat(document.getElementById('tiempo_real3').value);
    if (tiempo_real <= 0) {
        alert('El tiempo real no puede ser menor o igual a cero.');
        return;
    }
    const eficiencia = (tiempo_planeado / tiempo_real) * 100;
    const efectividad = (unidades_producidas / tiempo_planeado) * 100;
    document.getElementById('resultado3').innerHTML = `
        <p>Eficiencia: ${eficiencia.toFixed(2)}%</p>
        <p>Efectividad: ${efectividad.toFixed(2)}%</p>
    `;
});
