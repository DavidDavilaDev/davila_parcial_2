document.getElementById('formulario2').addEventListener('submit', function(event) {
    event.preventDefault();
    const eficacia = parseFloat(document.getElementById('eficacia2').value);
    const eficiencia = parseFloat(document.getElementById('eficiencia2').value);
    if (eficacia > 100 || eficiencia > 100) {
        alert('Los valores de eficacia y eficiencia no pueden ser mayores que 100%.');
        return;
    }
    const efectividad = (eficacia * eficiencia) / 100;
    document.getElementById('resultado2').innerHTML = `<p>Efectividad: ${efectividad.toFixed(2)}%</p>`;
});
