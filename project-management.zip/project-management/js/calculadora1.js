document.getElementById('formulario1').addEventListener('submit', function(event) {
    event.preventDefault();
    const realizados = parseFloat(document.getElementById('realizados1').value);
    const total = parseFloat(document.getElementById('total1').value);
    if (realizados > total) {
        alert('El número de logros alcanzados no puede ser mayor que el número total de objetivos.');
        return;
    }
    const efectividad = (realizados / total) * 100;
    document.getElementById('resultado1').innerHTML = `<p>Efectividad: ${efectividad.toFixed(2)}%</p>`;
});
