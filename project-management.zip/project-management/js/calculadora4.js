document.getElementById('formulario4').addEventListener('submit', function(event) {
    event.preventDefault();
    const inversion = parseFloat(document.getElementById('inversion4').value);
    const beneficio = parseFloat(document.getElementById('beneficio4').value);
    if (isNaN(inversion) || isNaN(beneficio)) {
        document.getElementById('resultado4').textContent = 'Error: Ingrese valores numéricos válidos.';
        return;
    }
    const roi = (beneficio - inversion) / inversion * 100;
    if (roi >= 0) {
        document.getElementById('resultado4').textContent = `ROI: ${roi.toFixed(2)}%`;
    } else {
        document.getElementById('resultado4').textContent = `ROI: -${(-roi).toFixed(2)}% (Pérdida)`;
    }
});
